package clase190423;

import java.util.Scanner;

public class prueba {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Scanner tc = new Scanner(System.in);
		
	float notas[],sum = 0,prom=0,prom3=0;
	float[] prom2= new float [10];
	int n=4,n2=10;
		
	
	try {
	notas = new float[n];
		for (int j=0;j<3;j++) {
		for (int i=0;i<notas.length;i++) {
			System.out.println("\nIngrese las notas del alumno "+(j+1));
			do {
			System.out.println("Ingrese la nota"+(i+1));
			notas[i]=tc.nextFloat();
			} while (notas[i]<0 || notas[i]>100);
		  sum += notas[i];
		  prom = sum/n;
			
		}
		System.out.println("Su promedio es = "+prom);
		
		
		
		
		prom= prom3;
		sum=0;
			
		}
	
		
		
	
	} catch (java.util.InputMismatchException m) {
		System.out.println("Error el dato tiene que ser entero");
	}
	}

}
